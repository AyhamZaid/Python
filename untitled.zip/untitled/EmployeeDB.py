import sqlite3

con = sqlite3.connect("Employee.db")
print("Database opened successfully")

print("Table created successfully")
con.close()



