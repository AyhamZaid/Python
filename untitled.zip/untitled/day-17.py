# -*- coding: utf-8 -*-
"""
Created on Wed Dec 11 11:36:25 2019

@author: Muath
"""
from flask import 
import sqlite3
app = Flask(__name__)

@app.route("/veiw")
def view():
    con = sqlite.connect("employee.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("select * from Employees")
    rows = cur.fetchall()
    return render_template("view.html", rows = rows)

@app.route("/delete")
def delete():
    return render_template("delete.html")

@app.route("/deleterecord", methods = ["POST"])
def deleterecord():
    id = request.form["id"]
    with sqlite3.connect("employee.db") as con:
        try:
            cur = con.curser()
            cur.execute("delete from Employees where id = ?", id)
            msg = "record has been deleted successfully"
        except:
            msg = "can't be deleted!"
        finally:
            return render_template("delete_record.html", msg = msg)

if __name__ == "__main__":
    app.run()